INSERT INTO absen (IDkaryawan,namaKaryawan, authDateTime, tanggal,jam,direction)
SELECT IDkaryawan, namaKaryawan, authDateTime,tanggal,jam,direction 
FROM hikvision 
WHERE NOT EXISTS (Select IDkaryawan,namaKaryawan, authDateTime, tanggal,jam,direction 
From absen  
WHERE absen.IDkaryawan = hikvision.IDkaryawan AND absen.tanggal=hikvision.tanggal);

-- INSERT INTO absen (IDkaryawan,tanggal,jam,direction,Location_Setting_Name,Location_GPS_Name,namaKaryawan,divisi,Location_Address,Location_Coordinate,[Description])
-- SELECT Employee_ID,[Date],Check_Time,[Type],Location_Setting_Name,Location_GPS_Name,Full_Name,Job_Position,Location_Address,Location_Coordinate,[Description]
-- FROM mekari 
-- WHERE NOT EXISTS (Select IDkaryawan,tanggal,jam,direction,Location_Setting_Name,Location_GPS_Name,namaKaryawan,divisi,Location_Address,Location_Coordinate,[Description] 
-- From absen t 
-- WHERE t.IDkaryawan 
-- IN (50,46,44,15,47,45,16,26,10,51,17,28,36,23,14,49,23));