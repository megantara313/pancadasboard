/*insert data from mekariDB to absen*/
-- INSERT INTO absen (IDkaryawan,tanggal,jam,direction,Location_Setting_Name,Location_GPS_Name,namaKaryawan,divisi,Location_Address,Location_Coordinate,[Description])
-- SELECT ID_Karyawan,[Date],Check_Time,[Type],Location_Setting_Name,Location_GPS_Name,Full_Name,Job_Position,Location_Address,Location_Coordinate,[Description]
-- FROM mekariDB 
-- WHERE NOT EXISTS (Select 1 From absen  with (updlock)
-- WHERE absen.IDkaryawan=mekariDB.ID_Karyawan and absen.tanggal=mekariDB.Date and absen.namaKaryawan=mekariDB.Full_Name);
 
 /*select from olahan (absen) table*/
 select * from absen;