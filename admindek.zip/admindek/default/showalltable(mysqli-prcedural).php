<?php
$serverName = "192.168.0.85"; // Replace with your SQL Server name
$connectionOptions = array(
    "Database" => "pancamanunggal", // Replace with your database name
    "Uid" => "sa", // Replace with your username
    "PWD" => "manunggal22" // Replace with your password
);

// Establishes the connection
$conn = sqlsrv_connect($serverName, $connectionOptions);

if ($conn === false) {
    die(print_r(sqlsrv_errors(), true));
}

// Retrieve the list of tables in the database
$tables = sqlsrv_query($conn, "SELECT namaKaryawan FROM absen");
if ($tables === false) {
    die(print_r(sqlsrv_errors(), true));
}

// Iterate over each table
while ($table = sqlsrv_fetch_array($tables, SQLSRV_FETCH_ASSOC)) {
    echo "<h2>Table: " . $table['IDkaryawan'] . "</h2>";
    
    // Retrieve the data from the current table
    $tableName = $table['IDkaryawan'];
    $sql = "SELECT * FROM $tableName";
    $stmt = sqlsrv_query($conn, $sql);
    if ($stmt === false) {
        die(print_r(sqlsrv_errors(), true));
    }
    
    // Output the data in a table format
    echo "<table>";
    echo "<tr><th>ID</th><th>Name</th><th>Age</th></tr>";
    while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        echo "<tr>";
        echo "<td>" . $row['IDkaryawan'] . "</td>";
        echo "<td>" . $row['namaKaryawan'] . "</td>";
        echo "<td>" . $row['tanggal'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    sqlsrv_free_stmt($stmt);
}

sqlsrv_free_stmt($tables);
sqlsrv_close($conn);
?>
