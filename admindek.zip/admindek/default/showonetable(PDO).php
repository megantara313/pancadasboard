<?php
// Database connection details
$servername = "192.168.0.85  ";
$username = "sa";
$password = "manunggal22";
$dbname = "pancamanunggal";

try {
    // Connect to the database
    $conn = new PDO("sqlsrv:Server=$servername;Database=$dbname", $username, $password);

    // Set the error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Prepare the SQL query
    $sql = "SELECT * FROM absen";
    $stmt = $conn->prepare($sql);

    // Execute the query
    $stmt->execute();

    // Fetch all the rows as associative arrays
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Process the data
    foreach ($result as $row) {
        // Access the columns by their names
        $column1Value = $row['IDkaryawan'];
        $column2Value = $row['tanggal'];
        $column3Value = $row['jam'];
        $column4Value = $row['direction'];
        $column5Value = $row['deviceName'];
        $column6Value = $row['deviceSN'];
        $column7Value = $row['namaKaryawan'];
        $column8Value = $row['noKartu'];
        $column9Value = $row['keterangan'];
        $column10Value = $row['uang_makan'];
        // ...
        // Process the values as needed
        // print $column1Value;
        // print $column2Value;
        // print $column3Value;
        // print $column4Value;
        // print $column5Value;
        // print $column6Value;
    }

} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}

?>

<!DOCTYPE html>
<html>
<head>
    <title>SQL Server Data Table</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }
        th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
    </style>
</head>
<body>
    <h2>SQL Server Data Table</h2>
    <table>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>tanggal</th>
            <th>jam</th>
            <?php
            echo "<tr>";
            echo "<td>" . $column1Value . "</td>";
            echo "<td>" . $column7Value . "</td>";
            echo "<td>" . $column2Value . "</td>";
            echo "<td>" . $column3Value . "</td>";
            echo "</tr>";
        ?>
        </tr>
    </table>
</body>
</html>