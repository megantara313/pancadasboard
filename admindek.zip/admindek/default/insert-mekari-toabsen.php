<?php
require_once('connect.php');
// $servername = "localhost";
// $username = "username";
// $password = "password";
// $dbname = "myDBPDO";

try {
  $conn = new PDO("sqlsrv:Server=$servername;Database=$db", $username, $password);
   // set the PDO error mode to exception
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
//   $sql = "INSERT INTO MyGuests (firstname, lastname, email)
//   VALUES ('John', 'Doe', 'john@example.com')";
$sql="INSERT INTO absen (IDkaryawan,tanggal,jam,direction,Location_Setting_Name,Location_GPS_Name,namaKaryawan,divisi,Location_Address,Location_Coordinate,[Description])
SELECT ID_Karyawan,[Date],Check_Time,[Type],Location_Setting_Name,Location_GPS_Name,Full_Name,Job_Position,Location_Address,Location_Coordinate,[Description]
FROM mekariDB 
WHERE NOT EXISTS (Select 1 From absen  
WHERE absen.IDkaryawan=mekariDB.ID_Karyawan and absen.tanggal=mekariDB.Date and absen.namaKaryawan=mekariDB.Full_Name);";
  // use exec() because no results are returned
 $result = $conn->exec($sql);
  // echo "New record created successfully";
}
 catch(PDOException $e) {
  echo $sql . "<br>" . $e->getMessage();
}

$conn = null;

?>