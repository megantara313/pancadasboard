<?php 
 
// Start session 
if(!session_id()){ 
    session_start(); 
} 
 
// Retrieve session data 
$sessData = !empty($_SESSION['sessData'])?$_SESSION['sessData']:''; 
 
// Get status message from session 
if(!empty($sessData['status']['msg'])){ 
    $statusMsg = $sessData['status']['msg']; 
    $statusMsgType = $sessData['status']['type']; 
    unset($_SESSION['sessData']['status']); 
} 
 
// Get member data 
$memberData = $userData = array(); 
if(!empty($_GET['id'])){ 
    // Include database configuration file 
    require_once 'connect.php'; 
     
    // Fetch data from SQL server by row ID 
    $sql = "SELECT * FROM absen WHERE IDkaryawan = ".$_GET['id']; 
    $query = $conn->prepare($sql); 
    $query->execute(); 
    $memberData = $query->fetch(PDO::FETCH_ASSOC); 
} 
$userData = !empty($sessData['userData'])?$sessData['userData']:$memberData; 
unset($_SESSION['sessData']['userData']); 
 
$actionLabel = !empty($_GET['id'])?'Edit':'Add'; 
 
?>

<!-- Display status message -->
<?php 
if(!empty($statusMsg) && ($statusMsgType == 'success'))
{ ?> <div class="col-xs-12"><div class="alert alert-success"><?php echo $statusMsg; ?></div></div><?php }
elseif(!empty($statusMsg) && ($statusMsgType == 'error'))
{ ?>
<div class="col-xs-12">
    <div class="alert alert-danger"><?php echo $statusMsg; ?></div>
</div>
<?php } 
?>

<!-- <div class="row">
    <div class="col-md-12">
        <h2><?php echo $actionLabel; ?> Member</h2>
    </div>
    <div class="col-md-6">
         <form method="post" action="userAction.php">
            <div class="form-group">
                <label>First Name</label>
                <input type="text" class="form-control" name="FirstName" placeholder="Enter your first name" value="<?php echo !empty($userData['FirstName'])?$userData['FirstName']:''; ?>" required="">
            </div>
            <div class="form-group">
                <label>Last Name</label>
                <input type="text" class="form-control" name="LastName" placeholder="Enter your last name" value="<?php echo !empty($userData['LastName'])?$userData['LastName']:''; ?>" required="">
            </div>
            <div class="form-group">
                <label>Email</label>
                <input type="email" class="form-control" name="Email" placeholder="Enter your email" value="<?php echo !empty($userData['Email'])?$userData['Email']:''; ?>" required="">
            </div>
            <div class="form-group">
                <label>Country</label>
                <input type="text" class="form-control" name="Country" placeholder="Enter country name" value="<?php echo !empty($userData['Country'])?$userData['Country']:''; ?>" required="">
            </div>
            
            <a href="index.php" class="btn btn-secondary">Back</a>
            <input type="hidden" name="MemberID" value="<?php echo !empty($userData['MemberID'])?$userData['MemberID']:''; ?>">
            <input type="submit" name="userSubmit" class="btn btn-success" value="Submited">
        </form>
    </div>
</div>

<div class="col-sm-12">
<div class="card o-visible">
<div class="card-header">
<h5>Tooltips On Textbox</h5>
</div>
<div class="card-block tooltip-icon button-list">
<div class="input-group">
<span class="input-group-prepend" id="name"><label class="input-group-text"><i class="icofont icofont-user-alt-3"></i></label></span>
<input type="text" class="form-control" placeholder="Enter your name" title="Enter your name" data-toggle="tooltip">
</div>
<div class="input-group">
<span class="input-group-prepend" id="name"><label class="input-group-text"><i class="icofont icofont-ui-email"></i></label></span>
<input type="text" class="form-control" placeholder="Enter email" title="Enter email" data-toggle="tooltip">
</div>
<button type="button" class="btn btn-primary waves-effect waves-light m-r-20" data-toggle="tooltip" data-placement="right" title="submit">Submit
</button>
</div>
</div> -->
<!-- below the code -->

<!DOCTYPE html>
<html lang="en">
<head>
<title>Autoflex | Admin pancamanunggal</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="description" content="Admindek Bootstrap admin template made using Bootstrap 4 and it has huge amount of ready made feature, UI components, pages which completely fulfills any dashboard needs." />
<meta name="keywords" content="bootstrap, bootstrap admin template, admin theme, admin dashboard, dashboard template, admin template, responsive" />
<meta name="author" content="colorlib" />

<link rel="icon" href="../files/assets/images/favicon.ico" type="image/x-icon">
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet"><link href="https://fonts.googleapis.com/css?family=Quicksand:500,700" rel="stylesheet">

<link rel="stylesheet" type="text/css" href="../files/bower_components/bootstrap/css/bootstrap.min.css">

<link rel="stylesheet" href="../files/assets/pages/waves/css/waves.min.css" type="text/css" media="all">

<link rel="stylesheet" type="text/css" href="../files/assets/icon/feather/css/feather.css">

<link rel="stylesheet" type="text/css" href="../files/assets/icon/themify-icons/themify-icons.css">

<link rel="stylesheet" type="text/css" href="../files/assets/icon/icofont/css/icofont.css">

<link rel="stylesheet" type="text/css" href="../files/assets/icon/font-awesome/css/font-awesome.min.css">

<link rel="stylesheet" type="text/css" href="../files/assets/css/style.css">
<link rel="stylesheet" type="text/css" href="../files/assets/css/pages.css">
</head>
<body>

<div class="loader-bg">
<div class="loader-bar"></div>
</div>

<div id="pcoded" class="pcoded">
<div class="pcoded-overlay-box"></div>
<div class="pcoded-container navbar-wrapper">

<nav class="navbar header-navbar pcoded-header">
<div class="navbar-wrapper">
<div class="navbar-logo">
<a href="../index-2.html">
<img class="img-fluid" src="../files/assets/images/logo.png" alt="Theme-Logo" />
</a>
<a class="mobile-menu" id="mobile-collapse" href="#!">
<i class="feather icon-menu icon-toggle-right"></i>
</a>
<a class="mobile-options waves-effect waves-light">
<i class="feather icon-more-horizontal"></i>
</a>
</div>
<div class="navbar-container container-fluid">
<ul class="nav-left">
<li class="header-search">
<div class="main-search morphsearch-search">
<div class="input-group">
<span class="input-group-prepend search-close">
<i class="feather icon-x input-group-text"></i>
</span>
<input type="text" class="form-control" placeholder="Enter Keyword">
<span class="input-group-append search-btn">
<i class="feather icon-search input-group-text"></i>
</span>
</div>
</div>
</li>
<li>
<a href="#!" onclick="javascript:toggleFullScreen()" class="waves-effect waves-light">
<i class="full-screen feather icon-maximize"></i>
</a>
</li>
</ul>
</div>
</li>
</ul>
</div>
</div>
</nav>

<div id="sidebar" class="users p-chat-user showChat">
<div class="had-container">
<div class="p-fixed users-main">
<div class="user-box">
<div class="chat-search-box">
<a class="back_friendlist">
<i class="feather icon-x"></i>
</a>
<div class="right-icon-control">
<div class="input-group input-group-button">
<input type="text" id="search-friends" name="footer-email" class="form-control" placeholder="Search Friend">
<div class="input-group-append">
<button class="btn btn-primary waves-effect waves-light" type="button"><i class="feather icon-search"></i></button>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>

<div class="pcoded-main-container">
<div class="pcoded-wrapper">

<nav class="pcoded-navbar">
<div class="nav-list">
<div class="pcoded-inner-navbar main-menu">
<div class="pcoded-navigation-label">Navigation</div>
<ul class="pcoded-item pcoded-left-item">
<li class="pcoded-hasmenu">
<a href="javascript:void(0)" class="waves-effect waves-dark">
<span class="pcoded-micon"><i class="feather icon-home"></i></span>
<span class="pcoded-mtext">Dashboard</span>
</a>
<ul class="pcoded-submenu">
<li class>
<a href="../index-2.html" class="waves-effect waves-dark">
<span class="pcoded-mtext">Default</span>
</a>
</li>
</ul>
</li>
</ul>
</nav>

<div class="pcoded-content">

<div class="page-header card">
<div class="row align-items-end">
<div class="col-lg-8">
<div class="page-header-title">
<i class="feather icon-clipboard bg-c-blue"></i>
<div class="d-inline">
<h5>Forms Modifikasi Data</h5>
<span>Edit baris data dari SQL Server</span>
</div>
</div>
</div>
</div>
</div>

<div class="pcoded-inner-content">
<div class="main-body">
<div class="page-wrapper">

<div class="page-body">
<div class="row">
<div class="col-sm-12">

<div class="card">
<div class="card-header">
<h5>Basic Inputs Validation</h5>
<span>Add class of <code>.form-control</code> with <code>&lt;input&gt;</code> tag</span>
</div>
<div class="card-block">
<form id="main" method="post" action="userAction.php">
<div class="form-group row">
<label class="col-sm-2 col-form-label">Nama karyawan</label>
<div class="col-sm-10">
<input type="text" class="form-control" name="name" id="name" placeholder="Text Input Validation">
<span class="messages"></span>
</div>
</div>
<div class="form-group row">
<label class="col-sm-2 col-form-label">Lokasi gps setting</label>
<div class="col-sm-10">
<input type="text" class="form-control" name="name" id="name" placeholder="Text Input Validation">
<span class="messages"></span>
</div>
</div>
<div class="form-group row">
<label class="col-sm-2 col-form-label">Deskripsi</label>
<div class="col-sm-10">
<input type="text" class="form-control" name="name" id="name" placeholder="Text Input Validation">
<span class="messages"></span>
</div>
</div>
<div class="row">
<label class="col-sm-2 col-form-label">Arah</label>
<div class="col-sm-10">
<div class="form-check form-check-inline">
<label class="form-check-label">
<input class="form-check-input" type="radio" name="gender" id="gender-1" value="option1"> Clock In
</label>
</div>
<div class="form-check form-check-inline">
<label class="form-check-label">
<input class="form-check-input" type="radio" name="gender" id="gender-2" value="option2"> Clock Out
</label>
</div>
<span class="messages"></span>
</div>
</div>

<!-- <div class="form-group row">
<label class="col-sm-2 col-form-label">Tanggal</label>
<div class="col-sm-10">
<input type="text" class="form-control date2" data-mask="9999-99-99"">
</div>
</div> -->

<div class="form-group row">
<label class="col-sm-2 col-form-label">Keterangan</label>
<div class="col-sm-10">
<input type="text" class="form-control" name="name" id="name" placeholder="Text Input Validation">
<span class="messages"></span>
</div>
</div>

<div class="form-group row">
<label class="col-sm-2 col-form-label">Email</label>
<div class="col-sm-10">
<input type="email" class="form-control" id="email" name="email" placeholder="Enter valid e-mail address">
<span class="messages"></span>
</div>
</div>

<div class="form-group row">
<label class="col-sm-2 col-form-label">Upload file</label>
<div class="col-sm-10 ">
<input type="file" class="form-control">
</div>
</div>

<div class="form-group row">
<label class="col-sm-2"></label>
<div class="col-sm-10">
<button type="submit" class="btn btn-primary m-b-0">Submit</button>
</div>
</div>
</form>
</div>
</div>


<!-- <div class="card">
<div class="card-header">
<h5>Tooltip Validation</h5>
<span>Add class of <code>.form-control</code> with <code>&lt;input&gt;</code> tag</span>
</div>
<div class="card-block">
<form id="second" action="https://demo.dashboardpack.com/" method="post" novalidate>
<div class="form-group row">
<label class="col-sm-2 col-form-label">Enter Username</label>
<div class="col-sm-10">
<input type="text" class="form-control" id="usernameP" name="Username" placeholder="Enter Username">
<span class="messages popover-valid"></span>
</div>
</div>
<div class="form-group row">
<label class="col-sm-2 col-form-label">Enter Email-id</label>
<div class="col-sm-10">
<input type="text" class="form-control" id="EmailP" name="Email" placeholder="Enter email id">
<span class="messages popover-valid"></span>
</div>
</div>
<div class="row">
<label class="col-sm-2"></label>
<div class="col-sm-10">
<button type="submit" class="btn btn-primary m-b-0">Submit</button>
</div>
</div>
</form>
</div>
</div>

<div class="card">
<div class="card-header">
<h5>Number Validation</h5>
<span>Add class of <code>.form-control</code> with <code>&lt;input&gt;</code> tag</span>
</div>
<div class="card-block">
<form id="number_form" action="https://demo.dashboardpack.com/" method="post" novalidate>
<div class="form-group row">
<label class="col-sm-2 col-form-label">Integers Only</label>
<div class="col-sm-10">
<input type="text" class="form-control" name="integer" id="integer" placeholder="Integers Only">
<span class="messages"></span>
</div>
</div>
<div class="form-group row">
<label class="col-sm-2 col-form-label">Numbers Only</label>
<div class="col-sm-10">
<input type="text" class="form-control" name="numeric" id="numeric" placeholder="Numbers Only">
<span class="messages"></span>
</div>
</div>
<div class="form-group row">
<label class="col-sm-2 col-form-label">Greater number</label>
<div class="col-sm-10">
<input type="text" class="form-control" name="Number" id="greater" placeholder="Number Greter than 50">
<span class="messages"></span>
</div>
</div>
<div class="form-group row">
<label class="col-sm-2 col-form-label">Less number</label>
<div class="col-sm-10">
<input type="text" class="form-control" name="Numbers" id="less" placeholder="Number Less than 50">
<span class="messages"></span>
</div>
</div>
<div class="row">
<label class="col-sm-2"></label>
<div class="col-sm-10">
<button type="submit" class="btn btn-primary m-b-0">Submit</button>
</div>
</div>
</form>
</div>
</div>

<div class="card">
<div class="card-header">
<h5>Form Components Validation</h5>
<span>Add class of <code>.form-control</code> with <code>&lt;input&gt;</code> tag</span>
</div>
<div class="card-block">
<form id="checkdrop" action="https://demo.dashboardpack.com/" method="post" novalidate>
<div class="form-group row">
<label class="col-sm-2">Radio Buttons</label>
<div class="col-sm-10">
<div class="form-radio">
<div class="radio radiofill radio-primary radio-inline">
<label>
<input type="radio" name="member" value="free" data-bv-field="member">
<i class="helper"></i>Select here
</label>
</div>
<div class="radio radiofill radio-primary radio-inline">
<label>
<input type="radio" name="member" value="personal" data-bv-field="member">
<i class="helper"></i>Another select
</label>
</div>
</div>
<span class="messages"></span>
</div>
</div>
<div class="form-group row">
<label class="col-sm-2">Select Checkbox</label>
<div class="col-sm-10">
<div class="checkbox-fade fade-in-primary">
<label>
<input type="checkbox" id="checkbox" name="Language" value="HTML">
<span class="cr">
<i class="cr-icon icofont icofont-ui-check txt-primary"></i>
</span>
<span>HTML</span>
</label>
</div>
<div class="checkbox-fade fade-in-primary">
<label>
<input type="checkbox" id="checkbox2" name="Language" value="CSS">
<span class="cr">
<i class="cr-icon icofont icofont-ui-check txt-primary"></i>
</span>
<span>CSS</span>
</label>
</div>
<span class="messages"></span>
</div>
</div>
<div class="row">
<label class="col-sm-2"></label>
<div class="col-sm-10">
<button type="submit" class="btn btn-primary m-b-0">Submit</button>
</div>
</div>
</form>
</div>
</div> -->

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div id="styleSelector">
</div>
</div>
</div>
</div>
</div>

<script type="text/javascript" src="../files/bower_components/jquery/js/jquery.min.js"></script>
<script type="text/javascript" src="../files/bower_components/jquery-ui/js/jquery-ui.min.js"></script>
<script type="text/javascript" src="../files/bower_components/popper.js/js/popper.min.js"></script>
<script type="text/javascript" src="../files/bower_components/bootstrap/js/bootstrap.min.js"></script>

<script src="../files/assets/pages/waves/js/waves.min.js"></script>

<script type="text/javascript" src="../files/bower_components/jquery-slimscroll/js/jquery.slimscroll.js"></script>

<script type="text/javascript" src="../files/bower_components/modernizr/js/modernizr.js"></script>
<script type="text/javascript" src="../files/bower_components/modernizr/js/css-scrollbars.js"></script>

<script src="../../../cdnjs.cloudflare.com/ajax/libs/underscore.js/1.8.3/underscore-min.js"></script>
<script src="../../../cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
<script type="text/javascript" src="../files/assets/pages/form-validation/validate.js"></script>

<!-- this 4 link js script -->
<script src="../files/assets/pages/form-masking/form-mask.js"></script> 
<script src="../files/assets/pages/form-masking/inputmask.js"></script>
<script src="../files/assets/pages/form-masking/jquery.inputmask.js"></script>
<script src="../files/assets/pages/form-masking/autoNumeric.js"></script>

<script type="text/javascript" src="../files/assets/pages/form-validation/form-validation.js"></script>
<script src="../files/assets/js/pcoded.min.js"></script>
<script src="../files/assets/js/vertical/vertical-layout.min.js"></script>
<script src="../files/assets/js/jquery.mCustomScrollbar.concat.min.js"></script>
<script type="text/javascript" src="../files/assets/js/script.js"></script>
</body>
</html>
