<?php
require_once('connect.php');
// $servername = "localhost";
// $username = "username";
// $password = "password";
// $dbname = "myDBPDO";

try {
  $conn = new PDO("sqlsrv:Server=$servername;Database=$db", $username, $password);
   // set the PDO error mode to exception
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
//   $sql = "INSERT INTO MyGuests (firstname, lastname, email)
//   VALUES ('John', 'Doe', 'john@example.com')";
  $sql="UPDATE absen  SET
  keterangan = case 
    when jam BETWEEN '03:00:00' and '08:00:59' and direction='Clock In' then 'hadir' 
   when jam BETWEEN '17:00:00' and '19:00:00' and direction='Clock Out'then 'pulang'
   when jam BETWEEN '15:01:00' and '16:59:00' and direction='Clock Out'then 'belum saatnya pulang'
   when jam BETWEEN '19:01:00' and '23:59:00' and direction='Clock Out'then 'lembur'
  when jam BETWEEN '10:00:00' and '12:00:00' and direction='Clock In' then 'cuti1/2hari'
  when jam BETWEEN '11:00:00' and '15:00:00' and direction='Clock Out' then 'cuti1/2hari'
 when jam BETWEEN '11:00:00' and '15:00:00' and direction='Clock In'then 'cuti1/2hari'
 when jam BETWEEN '08:01:00' and '10:00:00' and direction='Clock In'then 'terlambat'
 else 'tanya teknisi' 
 end;      
  -- uang_makan = case  
  -- when keterangan in ('hadir') and direction='Clock In' then '20000'
  -- when keterangan in('cuti1/2hari') and direction='Clock In' then '10000'
  -- when keterangan in('terlambat') and direction='Clock In' then 'tidak dapat'
  -- else 'kosong' 
  -- end;
  ";
  
  // use exec() because no results are returned
 $result = $conn->exec($sql);
  // echo "New record created successfully";
}
 catch(PDOException $e) {
  echo $sql . "<br>" . $e->getMessage();
}

$conn = null;

?>