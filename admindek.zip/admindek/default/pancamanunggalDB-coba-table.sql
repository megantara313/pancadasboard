-- SELECT * FROM absen
-- update coba set
--   info = case when time between '06.00.00' and '08.00.59' then 'attandence'
--               when time between '17.00.00' and '19.00.00' then 'go home'
--                 when time between '08.01.00' and '09.00.00' then 'late'
         
--          end,
--  salary = case when info = 'attandence' then '20.000'
--                 when info = 'go home' then 'nothing'
--                 when info = 'late' then '0'
--         end;

-- INSERT INTO coba (id, nama, time)
-- VALUES ('8', 'Tom', '08.01.00');

UPDATE absen SET
  keterangan = case 
    when jam BETWEEN '05:00:00' and '08:00:59' and direction='Clock In' then 'hadir' 
   when jam BETWEEN '17:00:00' and '19:00:00' and direction='Clock Out'then 'pulang'
  when jam BETWEEN '10:00:00' and '12:00:00' and direction='Clock In' then 'cuti1/2hari'
  when jam BETWEEN '11:00:00' and '15:00:00' and direction='Clock Out' then 'cuti1/2hari'
 when jam BETWEEN '11:00:00' and '15:00:00' and direction='Clock In'then 'cuti1/2hari'
 when jam BETWEEN '08:01:00' and '10:00:00' and direction='Clock In'then 'terlambat'
 else 'salah pencet' 
 end,      
  uang_makan = case  
  when keterangan in ('hadir') and direction in ('Clock In','Clock Out') then '20000' 
  when keterangan in('cuti1/2hari') and direction in ('Clock In','Clock Out') then '10000'
--   when keterangan in('hadir','cuti1/2hari') and direction in ('Clock In','Clock Out') then '10000'
  when keterangan in('terlambat') and direction='Clock In' then 'tidak dapat'
  else 'kosong' 
  end;
