<?php
require_once('connect.php');
// $servername = "localhost";
// $username = "username";
// $password = "password";
// $dbname = "myDBPDO";

try {
  $conn = new PDO("sqlsrv:Server=$servername;Database=$db", $username, $password);
   // set the PDO error mode to exception
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
//   $sql = "INSERT INTO MyGuests (firstname, lastname, email)
//   VALUES ('John', 'Doe', 'john@example.com')";
  $sql="UPDATE mekariDB
  SET ID_Karyawan 
  = CASE Full_Name
  WHEN 'Ahmad Dila Miftah Arzaq' THEN 100
  WHEN 'Bob Soros Subroto Probo Sutowo' THEN 101
  WHEN 'Rahmat Hidayatullah' THEN 104
  WHEN 'Dedi Joko Budiono' THEN 103
  WHEN 'Nuning Rika Endah S' THEN 55
  WHEN 'Bella Angelica Soesanto' THEN 102
  WHEN 'Muhammad Evanny Iqbal Ramadhani' THEN 113
  WHEN 'David Daniel Hendriano' THEN 106
  WHEN 'Virginia Ika Dani Nurgiyantari' THEN 107
  WHEN 'M Amanda Sohibul Ilham' THEN 105
  WHEN 'Fajar Bagus Arifianto' THEN 99
  WHEN 'Elleonora Diah Ayu Puspitasari' THEN 98
  WHEN 'Yakobus Agung Purwanto' THEN 97
  WHEN 'Shinta Fitriana Amelia' THEN 96
  WHEN 'Oei Maggie Wiharja' THEN 95
  WHEN 'Gabril Yan Adam' THEN 94
  WHEN 'Mustaqim' THEN 93
  WHEN 'Afdila Nirwanda Bintyarum' THEN 92
  WHEN 'Azka Aulananda Hukma Shabiyya' THEN 91
  WHEN 'Paksi Tri Atmaja' THEN 90
  WHEN 'Daniel Lewi Aprijanto' THEN 89
  WHEN 'Riska Nur Antika' THEN 88
  WHEN 'Ali Fauzan' THEN 87
  WHEN 'Hadi Sukamto' THEN 86
  WHEN 'Andos A Sinaga' THEN 85
  WHEN 'Rivaldo Ismir' THEN 84
  WHEN 'Andhika Bayu Ramadhan' THEN 83
  WHEN 'Eriana' THEN 82
  WHEN 'Muhammad Rizal Abdul Aziz A' THEN 81
  WHEN 'Salik Ario Seto Wicaksono' THEN 80
  WHEN 'Haryanto Efendi' THEN 79
  WHEN 'Fatmah Wati' THEN 78
  WHEN 'Anang Fuad Rifai' THEN 77
  WHEN 'Yhanian Tapa' THEN 76
  WHEN 'Rizqi Toni Kurniawan' THEN 75
  WHEN 'Sepridani Krisnawan' THEN 74
  WHEN 'Selvy Dwijayanti Santoso' THEN 73
  WHEN 'Nurcholis' THEN 72
  WHEN 'Murjayadi' THEN 71
  WHEN 'Adi Mardiyanto' THEN 70
  WHEN 'Adi Febriyono' THEN 69
  WHEN 'Sasono' THEN 68
  WHEN 'Istiadi' THEN 67
  WHEN 'Dimas Rofi Hidayat' THEN 66
  WHEN 'Andika Kusuma Wijaya' THEN 65
  WHEN 'Ade Setiyawan' THEN 64
  WHEN 'Hendy Arief Yuwono' THEN 63
  WHEN 'Yosi Adi Purnomo' THEN 62
  WHEN 'Agung Suryanaga' THEN 61
  WHEN 'Wahyu Hidayattuloh' THEN 60
  WHEN 'Edy Pramana' THEN 59
  WHEN 'Gatot Ganda Putra' THEN 58
  WHEN 'Muhamad Thoyiban' THEN 57
  WHEN 'Wijaya Handoko' THEN 56
  WHEN '	Nuning Rika Endah S' THEN 55
  WHEN 'Suharyono Trihadi' THEN 54
  WHEN 'Nurdiansyah Prahutama' THEN 53
  WHEN 'Ruben Manurung' THEN 52
  WHEN '	Yanuar Fiqri Dewa Dinandra' THEN 111
  WHEN 'Jon Pangestu' THEN 110
  WHEN 'Myke Hartoyo' THEN 109
  WHEN 'Danis Yhuda Kadarmanto' THEN 108
  WHEN 'Dwi Marini' THEN 109
  WHEN '	Myke Hartoyo' THEN 110
  WHEN 'Jon Pangestu' THEN 111
  WHEN 'Yanuar Fiqri Dewa Dinandra' THEN 112
  WHEN 'Budiono Wijaya' THEN 50
  WHEN 'Galang Yuda Husada' THEN 40
  WHEN 'Julius Antonius Juniantoro' THEN 46
  WHEN 'Dwinanto Budi Septyono' THEN 44
  WHEN 'Mayling' THEN 49
  WHEN 'Iqbal Rosadi' THEN 23
  WHEN 'Ngaidi' THEN 14
  WHEN 'Ngatiman' THEN 15
  WHEN 'Mulyono' THEN 47
  WHEN 'Rony Kristianto Wibowo' THEN 45
  WHEN 'Bernanta Munasmara' THEN 16
  WHEN 'Hery Prasetyo' THEN 26
  WHEN 'Tri Hariyanto' THEN 10
  WHEN 'Budi Sucipto' THEN 51
  WHEN 'Gilang Maulana Yuliantila' THEN 17
  WHEN 'Widya Arga Lakstata' THEN 28
  WHEN  'Harjanto' THEN 36
  ELSE Employee_ID
  END
  WHERE Full_Name IN ('Ahmad Dila Miftah Arzaq',          
  'Bob Soros Subroto Probo Sutowo', 
  'Rahmat Hidayatullah',           
  'Dedi Joko Budiono',             
  'Nuning Rika Endah S',           
  'Bella Angelica Soesanto',           
  'Muhammad Evanny Iqbal Ramadhani', 
  'David Daniel Hendriano',            
  'Virginia Ika Dani Nurgiyantari', 
  'M Amanda Sohibul Ilham',
  'Fajar Bagus Arifianto',
  'Elleonora Diah Ayu Puspitasari',
  'Yakobus Agung Purwanto',
  'Shinta Fitriana Amelia',
  'Oei Maggie Wiharja',
  'Gabril Yan Adam',
  'Mustaqim',
  'Afdila Nirwanda Bintyarum',
  'Azka Aulananda Hukma Shabiyya',
  'Paksi Tri Atmaja',
  'Daniel Lewi Aprijanto',
  'Riska Nur Antika',
  'Ali Fauzan',
  'Hadi Sukamto',
  'Andos A Sinaga', 
  'Rivaldo Ismir',
  'Andhika Bayu Ramadhan',
  'Eriana',
  'Muhammad Rizal Abdul Aziz A',
  'Salik Ario Seto Wicaksono',
  'Haryanto Efendi', 'Fatmah Wati' ,
   'Anang Fuad Rifai' ,
   'Yhanian Tapa' ,
   'Rizqi Toni Kurniawan' ,
   'Sepridani Krisnawan' ,
   'Selvy Dwijayanti Santoso' ,
   'Nurcholis' ,
   'Murjayadi' ,
   'Adi Mardiyanto' ,
   'Adi Febriyono' ,
   'Sasono' ,
   'Istiadi' ,
   'Dimas Rofi Hidayat' ,
   'Andika Kusuma Wijaya' ,
   'Ade Setiyawan' ,
   'Hendy Arief Yuwono' ,
   'Yosi Adi Purnomo' ,
   'Agung Suryanaga' ,
   'Wahyu Hidayattuloh' ,
   'Edy Pramana' ,
   'Gatot Ganda Putra' ,
   'Muhamad Thoyiban' ,
   'Wijaya Handoko' ,
   '	Nuning Rika Endah S' ,
   'Suharyono Trihadi' ,
   'Nurdiansyah Prahutama' ,
   'Ruben Manurung' ,
   '	Yanuar Fiqri Dewa Dinandra' ,
   'Jon Pangestu' ,
   'Myke Hartoyo' ,
   'Danis Yhuda Kadarmanto' ,
   'Dwi Marini' ,
   '	Myke Hartoyo' ,
   'Jon Pangestu' ,
   'Yanuar Fiqri Dewa Dinandra','Budiono Wijaya','Galang Yuda Husada','Julius Antonius Juniantoro','Dwinanto Budi Septyono','Mayling','Iqbal Rosadi','Ngaidi','Ngatiman','Mulyono',
  'Rony Kristianto Wibowo','Bernanta Munasmara','Hery Prasetyo','Tri Hariyanto',
  'Budi Sucipto','Gilang Maulana Yuliantila','Widya Arga Lakstata','Widya Arga Lakstata',
  'Harjanto');
  ";
  // use exec() because no results are returned
 $result = $conn->exec($sql);
  // echo "New record created successfully";
}
 catch(PDOException $e) {
  echo $sql . "<br>" . $e->getMessage();
}

$conn = null;

?>