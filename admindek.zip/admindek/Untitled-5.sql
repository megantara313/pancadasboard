-- SELECT * FROM table1;

  -- DELETE FROM table1;

-- SELECT table1.ID_karyawan, table1.nama_karyawan, MIN(jam) ,MIN(tanggal),table1.arah
-- FROM table1 
-- GROUP BY ID_karyawan, nama_karyawan,jam,tanggal,arah

/*start query*/
-- SELECT table1.ID_karyawan, table1.nama_karyawan, table1.jam ,table1.tanggal,table1.arah
-- FROM table1 
-- GROUP BY ID_karyawan, nama_karyawan,jam,tanggal,arah;

/*start query*/
-- DELETE FROM table1
-- WHERE ID_karyawan NOT IN (
--     SELECT MIN(ID_karyawan)
--     FROM table1
--     GROUP BY ID_karyawan
-- );

/*query to tidy up masuk dan keluar*/
-- SELECT table1.ID_karyawan, table1.nama_karyawan, MIN(jam) ,MIN(tanggal),table1.arah
-- FROM table1 
-- GROUP BY ID_karyawan, nama_karyawan,jam,tanggal,arah;


/*query to tidy up masuk dan keluar*/
-- SELECT table1.ID_karyawan, table1.nama_karyawan, table1.jam ,table1.tanggal,table1.arah
-- FROM table1 
-- GROUP BY ID_karyawan, nama_karyawan,jam,tanggal,arah;


-- /*start query for delete unselected min max time but fail for much data*/
-- WITH tanggal AS
-- (SELECT ID_karyawan, 
-- MIN(jam) AS minDate, 
-- MAX(jam) AS maxDate
-- FROM table1
-- GROUP BY ID_karyawan)
-- DELETE FROM table1
--   WHERE 
--     NOT EXISTS 
--       (SELECT * FROM tanggal d 
--         WHERE table1.ID_karyawan = d.ID_karyawan 
--           AND table1.jam IN (d.minDate, d.maxDate));
-- SELECT table1.ID_karyawan, table1.nama_karyawan, MIN(jam) ,MIN(tanggal),table1.arah
-- FROM table1 
-- GROUP BY ID_karyawan, nama_karyawan,jam,tanggal,arah;
-- SELECT * FROM table1 ORDER BY ID_karyawan DESC, jam DESC

-- /*start query1 pivoting table*/
-- SELECT (ColumnNames)  
-- FROM (TableName)  
-- PIVOT
-- (  
--   AggregateFunction(ColumnToBeAggregated)
--   FOR PivotColumn IN (PivotColumnValues)
-- ) AS (Alias);                                   

/*start query2 pivoting table*/
-- SELECT * FROM table1  
--  PIVOT
-- (AVG(jam) FOR arah IN (masuk,keluar)) AS PivotTable;

/*start query3 pivoting table*/
-- SELECT *
-- FROM
--     (
--     SELECT [ID_karyawan],
--         [nama_karyawan],
--         [jam],
--         [tanggal],
--         [arah]
--     FROM [dbo].[table1]
-- ) AS SourceTable PIVOT(AVG([jam]) FOR [arah] 
-- IN([masuk],[keluar])) AS PivotTable;


-- With r as(
--  select Per_code,Date,Time,
--  row_number()over(partition by Per_Code,Date order by Time) rn from temp)
--   select   Per_code,Date,
--       max(case when   rn=1  then Time end) In,
--       max(case when   rn=7  then Time end) Out,
--       max(case when   rn=2  then Time end) Break,
--       max(case when   rn=3  then Time end) Return
--   from r group by  Per_code,Date
-- union
--   select   Per_code,Date,
--       max(case when   rn=1  then Time end) In,
--       max(case when   rn=7  then Time end) Out,
--       max(case when   rn=5  then Time end) Break,
--       max(case when   rn=6  then Time end) Return
--   from r group by  Per_code,Date

/*start query4 transpose rows table*/
-- With r as(
--  select ID_karyawan,jam,
--  row_number()over(partition by ID_karyawan order by jam) row_number from )
--   select ID_karyawan,
--       max(case when   row_number=1  then jam end) time_in,
--       max(case when   row_number=2  then jam end) time_out
--   from r group by  ID_karyawan
-- union
--   select   ID_karyawan,
--       max(case when   row_number=1  then jam end) time_in,
--       max(case when   row_number=2  then jam end) time_out
--   from r group by  ID_karyawan


-- SELECT * FROM table1;
-- DELETE FROM table1;
-- SELECT * FROM procestable;
-- DELETE FROM procestable;

/*Insert data into the proces table by transposing rows to columns*/
-- INSERT INTO procestable (id,name, time_in, time_out,date,info1,info2)
-- SELECT ID_karyawan
--      , nama_karyawan
--      , MAX(CASE WHEN row_number = 1 THEN jam END) as time_in
--      , MAX(CASE WHEN row_number = 2 THEN jam END) as time_out
--      , tanggal
--      , MAX(CASE WHEN row_number = 1 THEN arah END) as info1
--      , MAX(CASE WHEN row_number = 2 THEN arah END) as info2
--   FROM (SELECT ID_karyawan
--              , nama_karyawan
--              , jam
--              , tanggal
--              , arah
--              , ROW_NUMBER() OVER (PARTITION BY ID_karyawan
--                                           , nama_karyawan
--                                           , tanggal
--                                       ORDER BY jam
--                                           ,arah
--                                  ) as row_number
--           FROM table1
--        ) AS table1
--  GROUP BY ID_karyawan
--      , nama_karyawan
--      , tanggal
--  order by tanggal
--      , ID_karyawan;

/*Insert data into the new table by transposing rows to columns*/
-- INSERT INTO procestable (ID_karyawan, time_in, time_out)
-- SELECT
--     ID_karyawan,
--     MIN(CASE WHEN ROW_NUMBER() = 1 THEN jam END) as time_in,
--     MAX(CASE WHEN ROW_NUMBER() = 2 THEN jam END) as time_out
-- FROM (
--     SELECT
--         ID_karyawan,jam,
--         ROW_NUMBER() OVER (PARTITION BY ID_karyawan ORDER BY jam ) as ROW_NUMBER
--     FROM table1 t
-- ) AS t
-- GROUP BY ID_karyawan;


/*Insert data into the new table by transposing rows to columns*/
-- INSERT INTO transposed_table (item_id, datetime_1, datetime_2)
-- SELECT
--     item_id,
--     MAX(CASE WHEN row_number = 1 THEN datetime END) as datetime_1,
--     MAX(CASE WHEN row_number = 2 THEN datetime END) as datetime_2
-- FROM (
--     SELECT
--         item_id,
--         datetime,
--         ROW_NUMBER() OVER (PARTITION BY item_id ORDER BY datetime) as row_number
--     FROM original_table
-- ) AS temp
-- GROUP BY item_id;


/*start query*/
-- DROP TABLE [table1];

/*insert only 2 column data into tbl1*/
-- INSERT INTO table1 VALUES 
-- (1,N'07:44:45'),
-- 	(1,N'17:04:46'),
-- 	(3,N'06:58:41'),
-- 	(3,N'17:24:41'),
--   (1,N'07:44:45'),
-- 	(1,N'17:04:46'),
-- 	(3,N'06:58:41'),
-- 	(3,N'17:24:41');


/*insert very less data into tbl1*/
-- INSERT INTO table1 VALUES (1,N'ridho',N'07:44:45',N'2023-07-20',N'masuk'),
-- 	(1,N'ridho ',N'17:04:46',N'2023-07-20',N'keluar'),
-- 	(3,N'Yuwono',N'06:58:41',N'2023-07-20',N'masuk'),
-- 	(3,N'Yuwono',N'17:24:41',N'2023-07-20',N'keluar'),
--   (1,N'ridho',N'07:44:45',N'2023-07-21 00:00:00',N'masuk'),
-- 	(1,N'ridho',N'17:04:46',N'2023-07-21 00:00:00',N'keluar'),
-- 	(3,N'Yuwono',N'06:58:41',N'2023-07-21 00:00:00',N'masuk'),
-- 	(3,N'Yuwono',N'17:24:41',N'2023-07-21 00:00:00',N'keluar');



SELECT * FROM table1;
/*start query insert less data into table1*/
-- IF NOT EXISTS (
--     select * from table1 
-- ) 
-- CREATE TABLE table1 (
--     [ID_karyawan] INT,
--     [nama_karyawan] NVARCHAR(32),
--     [jam] NVARCHAR(8),
--     [tanggal] NVARCHAR(19),
--     [arah] NVARCHAR(6)
-- );
-- BEGIN
--    IF NOT EXISTS (SELECT * FROM table1 
--                    WHERE De = ID_karyawan
--                    AND Assunto = nama_karyawan
--                    AND Daa = jam
--                    AND tgl = tanggal
--                    AND arah = arah)
--    BEGIN
-- INSERT INTO table1 (ID_karyawan,nama_karyawan,jam,tanggal,arah) VALUES (1,N'ridho azhar megantara',N'07:44:45',N'2023-07-20',N'masuk'),
-- (1,N'ridho azhar megantara',N'06:44:45',N'2023-07-23',N'masuk'),
-- (1,N'ridho azhar megantara',N'06:44:45',N'2023-07-21',N'masuk'),
-- 	(1,N'ridho azhar megantara',N'17:04:46',N'2023-07-20',N'keluar'),
-- 	(3,N'Hendy Arief Yuwono',N'17:24:47',N'2023-07-20',N'keluar'),
-- 	(3,N'Hendy Arief Yuwono',N'06:58:41',N'2023-07-20',N'masuk'),
-- 	(3,N'Hendy Arief Yuwono',N'17:24:41',N'2023-07-20',N'keluar'),
-- 	(4,N'Ety wulandari',N'07:51:48',N'2023-07-20',N'masuk'),
-- 	(4,N'Ety wulandari',N'17:04:07',N'2023-07-20',N'keluar'),
-- 	(5,N'Joseph Tan',N'17:03:48',N'2023-07-20',N'keluar'),
-- 	(5,N'Joseph Tan',N'07:40:31',N'2023-07-20',N'masuk'),
-- 	(1,N'ridho azhar megantara',N'07:44:45',N'2023-07-21 00:00:00',N'masuk'),
-- 	(1,N'ridho azhar megantara',N'17:04:46',N'2023-07-21 00:00:00',N'keluar'),
-- 	(3,N'Hendy Arief Yuwono',N'17:24:47',N'2023-07-21 00:00:00',N'keluar'),
-- 	(3,N'Hendy Arief Yuwono',N'06:58:41',N'2023-07-21 00:00:00',N'masuk'),
-- 	(3,N'Hendy Arief Yuwono',N'17:24:41',N'2023-07-21 00:00:00',N'keluar'),
-- 	(4,N'Ety wulandari',N'07:51:48',N'2023-07-21 00:00:00',N'masuk'),
-- 	(4,N'Ety wulandari',N'17:04:07',N'2023-07-21 00:00:00',N'keluar'),
-- 	(5,N'Joseph Tan',N'17:03:48',N'2023-07-21 00:00:00',N'keluar'),
-- 	(5,N'Joseph Tan',N'07:40:31',N'2023-07-21 00:00:00',N'masuk')
--   WHERE NOT EXISTS (
--     SELECT *
--     FROM table1
--     WHERE ID_karyawan IN (1,3,4,5)
-- );

/*try query1 to insert if not exist/where is not exist*/
-- INSERT INTO table1 (ID_karyawan,nama_karyawan,jam,tanggal,arah)
-- SELECT  table1.ID_karyawan,table1.nama_karyawan,table1.jam,table1.tanggal,table1.arah
-- FROM  table1 ( VALUES (5,N'Joseph Tan',N'07:40:31',N'2023-07-23 00:00:00',N'masuk') ) AS iu (ID_karyawan)
-- WHERE   NOT EXISTS ( SELECT 1
--                      FROM   table1 AS MT
--                      WHERE  MT.ID_karyawan = iu.ID_karyawan );

/*query2 to try if not exsist/where is not exist in rows value*/
-- INSERT INTO table1
--             (ID_karyawan, 
--             nama_karyawan, 
--             jam, 
--             tanggal, 
--             arah)
--     SELECT 1,N'ridho azhar megantara',N'07:44:45',N'2023-07-20',N'masuk'
--     WHERE NOT EXISTS
--         (SELECT 1
--          FROM table1
--          WHERE ID_karyawan = 1
--            AND nama_karyawan = 'ridho azhar megantara')

/*query3 to try if not exsist/where is not exist in rows value*/
-- merge into 
--     [dbo].[table1] with (holdlock) t  
-- using 
--     (values (1,N'ridho azhar megantara',N'07:44:45',N'2023-07-20',N'masuk')) s([ID_karyawan], [nama_karyawan],[jam],[tanggal],[arah]) 
-- on 
--     t.[ID_karyawan] = s.[ID_karyawan] and t.[nama_karyawan] = s.[nama_karyawan] and t.[jam] = s.[jam] and t.[tanggal] = s.[tanggal] and t.[arah] = s.[arah] 
-- when not matched then 
--     insert values (s.[ID_karyawan], s.[nama_karyawan], s.[jam], s.[tanggal], s.[arah]);

/*start query insert many data into table1*/
-- IF NOT EXISTS (
--     select * from sysobjects where name='table1' and xtype='U'
-- ) CREATE TABLE table1 (
--     [ID_karyawan] INT,
--     [nama_karyawan] NVARCHAR(32),
--     [jam] NVARCHAR(8),
--     [tanggal] NVARCHAR(19),
--     [arah] NVARCHAR(6)
-- );
-- INSERT INTO table1 VALUES (1,N'ridho azhar megantara',N'07:44:45',N'2023-07-20',N'masuk'),
-- 	(1,N'ridho azhar megantara',N'17:04:46',N'2023-07-20',N'keluar'),
-- 	(3,N'Hendy Arief Yuwono',N'17:24:47',N'2023-07-20',N'keluar'),
-- 	(3,N'Hendy Arief Yuwono',N'06:58:41',N'2023-07-20',N'masuk'),
-- 	(3,N'Hendy Arief Yuwono',N'17:24:41',N'2023-07-20',N'keluar'),
-- 	(4,N'Ety wulandari',N'07:51:48',N'2023-07-20',N'masuk'),
-- 	(4,N'Ety wulandari',N'17:04:07',N'2023-07-20',N'keluar'),
-- 	(5,N'Joseph Tan',N'17:03:48',N'2023-07-20',N'keluar'),
-- 	(5,N'Joseph Tan',N'07:40:31',N'2023-07-20',N'masuk'),
-- 	(6,N'Herry Joko Susilo',N'17:04:16',N'2023-07-20',N'keluar'),
-- 	(6,N'Herry Joko Susilo',N'07:26:11',N'2023-07-20',N'masuk'),
-- 	(6,N'Herry Joko Susilo',N'07:26:16',N'2023-07-20',N'masuk'),
-- 	(7,N'Martha Ayu Wulandari',N'07:49:53',N'2023-07-20',N'masuk'),
-- 	(7,N'Martha Ayu Wulandari',N'07:50:23',N'2023-07-20',N'masuk'),
-- 	(7,N'Martha Ayu Wulandari',N'17:04:43',N'2023-07-20',N'keluar'),
-- 	(8,N'Aries Krisnawan',N'17:04:30',N'2023-07-20',N'keluar'),
-- 	(8,N'Aries Krisnawan',N'07:49:06',N'2023-07-20',N'masuk'),
-- 	(8,N'Aries Krisnawan',N'07:49:11',N'2023-07-20',N'masuk'),
-- 	(8,N'Aries Krisnawan',N'17:04:34',N'2023-07-20',N'keluar'),
-- 	(10,N'Tri Hariyanto',N'17:00:23',N'2023-07-20',N'keluar'),
-- 	(10,N'Tri Hariyanto',N'07:40:40',N'2023-07-20',N'masuk'),
-- 	(12,N'Harmanto',N'17:45:22',N'2023-07-20',N'keluar'),
-- 	(12,N'Harmanto',N'07:55:34',N'2023-07-20',N'masuk'),
-- 	(12,N'Harmanto',N'17:45:04',N'2023-07-20',N'keluar'),
-- 	(13,N'Leanne Damayanti',N'07:58:19',N'2023-07-20',N'masuk'),
-- 	(13,N'Leanne Damayanti',N'07:58:15',N'2023-07-20',N'masuk'),
-- 	(13,N'Leanne Damayanti',N'17:10:41',N'2023-07-20',N'keluar'),
-- 	(13,N'Leanne Damayanti',N'17:10:44',N'2023-07-20',N'keluar'),
-- 	(14,N'ngaidi',N'17:01:11',N'2023-07-20',N'keluar'),
-- 	(14,N'ngaidi',N'07:17:21',N'2023-07-20',N'masuk'),
-- 	(15,N'Ngatiman',N'17:01:16',N'2023-07-20',N'keluar'),
-- 	(15,N'Ngatiman',N'07:32:26',N'2023-07-20',N'masuk'),
-- 	(16,N'Bernanta Munasmara',N'17:08:10',N'2023-07-20',N'keluar'),
-- 	(16,N'Bernanta Munasmara',N'07:40:35',N'2023-07-20',N'masuk'),
-- 	(17,N'Gilang Maulana Yuliantila',N'07:48:54',N'2023-07-20',N'masuk'),
-- 	(18,N'Cynthia Lavina',N'17:07:02',N'2023-07-20',N'keluar'),
-- 	(18,N'Cynthia Lavina',N'07:36:38',N'2023-07-20',N'masuk'),
-- 	(19,N'Dwiana Danawati',N'07:56:24',N'2023-07-20',N'masuk'),
-- 	(19,N'Dwiana Danawati',N'17:17:43',N'2023-07-20',N'keluar'),
-- 	(20,N'Rokip',N'17:42:22',N'2023-07-20',N'keluar'),
-- 	(20,N'Rokip',N'07:14:24',N'2023-07-20',N'masuk'),
-- 	(20,N'Rokip',N'07:14:28',N'2023-07-20',N'masuk'),
-- 	(20,N'Rokip',N'17:42:19',N'2023-07-20',N'keluar'),
-- 	(21,N'Alvina Rizki',N'17:10:34',N'2023-07-20',N'keluar'),
-- 	(21,N'Alvina Rizki',N'07:57:46',N'2023-07-20',N'masuk'),
-- 	(22,N'Yuniar agung prabowo',N'07:58:05',N'2023-07-20',N'masuk'),
-- 	(22,N'Yuniar agung prabowo',N'17:02:10',N'2023-07-20',N'keluar'),
-- 	(23,N'Muhamad ikbal rosadi',N'17:07:19',N'2023-07-20',N'keluar'),
-- 	(23,N'Muhamad ikbal rosadi',N'07:56:53',N'2023-07-20',N'masuk'),
-- 	(24,N'Silvy Natalia',N'07:59:36',N'2023-07-20',N'masuk'),
-- 	(24,N'Silvy Natalia',N'17:04:24',N'2023-07-20',N'keluar'),
-- 	(24,N'Silvy Natalia',N'07:59:40',N'2023-07-20',N'masuk'),
-- 	(24,N'Silvy Natalia',N'17:04:20',N'2023-07-20',N'keluar'),
-- 	(24,N'Silvy Natalia',N'17:09:40',N'2023-07-20',N'keluar'),
-- 	(25,N'Shely',N'07:58:47',N'2023-07-20',N'masuk'),
-- 	(25,N'Shely',N'17:09:35',N'2023-07-20',N'keluar'),
-- 	(26,N'Hery prasetyo',N'07:43:17',N'2023-07-20',N'masuk'),
-- 	(27,N'Monica Mellyanawati',N'17:33:34',N'2023-07-20',N'keluar'),
-- 	(27,N'Monica Mellyanawati',N'07:50:19',N'2023-07-20',N'masuk'),
-- 	(30,N'Wahyu pusporini (arini)',N'07:25:49',N'2023-07-20',N'masuk'),
-- 	(30,N'Wahyu pusporini (arini)',N'17:05:42',N'2023-07-20',N'keluar'),
-- 	(31,N'Rebeca Kristina Lopia Simatupang',N'07:51:08',N'2023-07-20',N'masuk'),
-- 	(31,N'Rebeca Kristina Lopia Simatupang',N'17:11:29',N'2023-07-20',N'keluar'),
-- 	(32,N'Hendrik Pudjo Widodo',N'17:05:37',N'2023-07-20',N'keluar'),
-- 	(32,N'Hendrik Pudjo Widodo',N'07:53:37',N'2023-07-20',N'masuk'),
-- 	(33,N'Melati',N'17:20:52',N'2023-07-20',N'keluar'),
-- 	(33,N'Melati',N'07:21:05',N'2023-07-20',N'masuk'),
-- 	(34,N'Addy putro wahyuono',N'17:35:47',N'2023-07-20',N'keluar'),
-- 	(34,N'Addy putro wahyuono',N'07:29:40',N'2023-07-20',N'masuk'),
-- 	(34,N'Addy putro wahyuono',N'07:29:33',N'2023-07-20',N'masuk'),
-- 	(35,N'Ron reni Mayliana',N'07:55:31',N'2023-07-20',N'masuk'),
-- 	(35,N'Ron reni Mayliana',N'17:06:01',N'2023-07-20',N'keluar'),
-- 	(35,N'Ron reni Mayliana',N'07:45:27',N'2023-07-20',N'masuk'),
-- 	(36,N'Harjanto',N'07:49:26',N'2023-07-20',N'masuk'),
-- 	(36,N'Harjanto',N'17:03:07',N'2023-07-20',N'keluar'),
-- 	(37,N'Ong Lie Djing',N'07:57:15',N'2023-07-20',N'masuk'),
-- 	(37,N'Ong Lie Djing',N'17:14:43',N'2023-07-20',N'keluar'),
-- 	(38,N'Ashley Prawesti Swandini',N'17:09:43',N'2023-07-20',N'keluar'),
-- 	(38,N'Ashley Prawesti Swandini',N'07:47:52',N'2023-07-20',N'masuk'),
-- 	(39,N'Pudji Guntoro',N'07:51:35',N'2023-07-20',N'masuk'),
-- 	(39,N'Pudji Guntoro',N'17:07:45',N'2023-07-20',N'keluar'),
-- 	(41,N'Muchamad Rifai',N'17:08:03',N'2023-07-20',N'keluar'),
-- 	(41,N'Muchamad Rifai',N'07:10:58',N'2023-07-20',N'masuk'),
-- 	(43,N'Mudiono',N'07:29:42',N'2023-07-20',N'masuk'),
-- 	(43,N'Mudiono',N'17:14:00',N'2023-07-20',N'keluar'),
-- 	(44,N'Dwinanto Budi Septyono',N'17:08:07',N'2023-07-20',N'keluar'),
-- 	(44,N'Dwinanto Budi Septyono',N'07:27:51',N'2023-07-20',N'masuk'),
-- 	(45,N'Rony Kristianto Wibowo',N'07:50:48',N'2023-07-20',N'masuk'),
-- 	(46,N'Julius Antonius Juniantoro',N'07:45:33',N'2023-07-20',N'masuk'),
-- 	(47,N'Mulyono',N'17:06:33',N'2023-07-20',N'keluar'),
-- 	(47,N'Mulyono',N'07:46:16',N'2023-07-20',N'masuk'),
-- 	(47,N'Mulyono',N'07:46:21',N'2023-07-20',N'masuk'),
-- 	(48,N'Kusno',N'17:01:25',N'2023-07-20',N'keluar'),
-- 	(48,N'Kusno',N'07:44:40',N'2023-07-20',N'masuk'),
-- 	(49,N'Evita ling',N'17:07:50',N'2023-07-20',N'keluar'),
-- 	(49,N'Evita ling',N'07:37:02',N'2023-07-20 00:00:00',N'masuk'),
-- 	(1,N'ridho azhar megantara',N'07:44:45',N'2023-07-21 00:00:00',N'masuk'),
-- 	(1,N'ridho azhar megantara',N'17:04:46',N'2023-07-21 00:00:00',N'keluar'),
-- 	(3,N'Hendy Arief Yuwono',N'17:24:47',N'2023-07-21 00:00:00',N'keluar'),
-- 	(3,N'Hendy Arief Yuwono',N'06:58:41',N'2023-07-21 00:00:00',N'masuk'),
-- 	(3,N'Hendy Arief Yuwono',N'17:24:41',N'2023-07-21 00:00:00',N'keluar'),
-- 	(4,N'Ety wulandari',N'07:51:48',N'2023-07-21 00:00:00',N'masuk'),
-- 	(4,N'Ety wulandari',N'17:04:07',N'2023-07-21 00:00:00',N'keluar'),
-- 	(5,N'Joseph Tan',N'17:03:48',N'2023-07-21 00:00:00',N'keluar'),
-- 	(5,N'Joseph Tan',N'07:40:31',N'2023-07-21 00:00:00',N'masuk'),
-- 	(6,N'Herry Joko Susilo',N'17:04:16',N'2023-07-21 00:00:00',N'keluar'),
-- 	(6,N'Herry Joko Susilo',N'07:26:11',N'2023-07-21 00:00:00',N'masuk'),
-- 	(6,N'Herry Joko Susilo',N'07:26:16',N'2023-07-21 00:00:00',N'masuk'),
-- 	(7,N'Martha Ayu Wulandari',N'07:49:53',N'2023-07-21 00:00:00',N'masuk'),
-- 	(7,N'Martha Ayu Wulandari',N'07:50:23',N'2023-07-21 00:00:00',N'masuk'),
-- 	(7,N'Martha Ayu Wulandari',N'17:04:43',N'2023-07-21 00:00:00',N'keluar'),
-- 	(8,N'Aries Krisnawan',N'17:04:30',N'2023-07-21 00:00:00',N'keluar'),
-- 	(8,N'Aries Krisnawan',N'07:49:06',N'2023-07-21 00:00:00',N'masuk'),
-- 	(8,N'Aries Krisnawan',N'07:49:11',N'2023-07-21 00:00:00',N'masuk'),
-- 	(8,N'Aries Krisnawan',N'17:04:34',N'2023-07-21 00:00:00',N'keluar'),
-- 	(10,N'Tri Hariyanto',N'17:00:23',N'2023-07-21 00:00:00',N'keluar'),
-- 	(10,N'Tri Hariyanto',N'07:40:40',N'2023-07-21 00:00:00',N'masuk'),
-- 	(12,N'Harmanto',N'17:45:22',N'2023-07-21 00:00:00',N'keluar'),
-- 	(12,N'Harmanto',N'07:55:34',N'2023-07-21 00:00:00',N'masuk'),
-- 	(12,N'Harmanto',N'17:45:04',N'2023-07-21 00:00:00',N'keluar'),
-- 	(13,N'Leanne Damayanti',N'07:58:19',N'2023-07-21 00:00:00',N'masuk'),
-- 	(13,N'Leanne Damayanti',N'07:58:15',N'2023-07-21 00:00:00',N'masuk'),
-- 	(13,N'Leanne Damayanti',N'17:10:41',N'2023-07-21 00:00:00',N'keluar'),
-- 	(13,N'Leanne Damayanti',N'17:10:44',N'2023-07-21 00:00:00',N'keluar'),
-- 	(14,N'ngaidi',N'17:01:11',N'2023-07-21 00:00:00',N'keluar'),
-- 	(14,N'ngaidi',N'07:17:21',N'2023-07-21 00:00:00',N'masuk'),
-- 	(15,N'Ngatiman',N'17:01:16',N'2023-07-21 00:00:00',N'keluar'),
-- 	(15,N'Ngatiman',N'07:32:26',N'2023-07-21 00:00:00',N'masuk'),
-- 	(16,N'Bernanta Munasmara',N'17:08:10',N'2023-07-21 00:00:00',N'keluar'),
-- 	(16,N'Bernanta Munasmara',N'07:40:35',N'2023-07-21 00:00:00',N'masuk'),
-- 	(17,N'Gilang Maulana Yuliantila',N'07:48:54',N'2023-07-21 00:00:00',N'masuk'),
-- 	(18,N'Cynthia Lavina',N'17:07:02',N'2023-07-21 00:00:00',N'keluar'),
-- 	(18,N'Cynthia Lavina',N'07:36:38',N'2023-07-21 00:00:00',N'masuk'),
-- 	(19,N'Dwiana Danawati',N'07:56:24',N'2023-07-21 00:00:00',N'masuk'),
-- 	(19,N'Dwiana Danawati',N'17:17:43',N'2023-07-21 00:00:00',N'keluar'),
-- 	(20,N'Rokip',N'17:42:22',N'2023-07-21 00:00:00',N'keluar'),
-- 	(20,N'Rokip',N'07:14:24',N'2023-07-21 00:00:00',N'masuk'),
-- 	(20,N'Rokip',N'07:14:28',N'2023-07-21 00:00:00',N'masuk'),
-- 	(20,N'Rokip',N'17:42:19',N'2023-07-21 00:00:00',N'keluar'),
-- 	(21,N'Alvina Rizki',N'17:10:34',N'2023-07-21 00:00:00',N'keluar'),
-- 	(21,N'Alvina Rizki',N'07:57:46',N'2023-07-21 00:00:00',N'masuk'),
-- 	(22,N'Yuniar agung prabowo',N'07:58:05',N'2023-07-21 00:00:00',N'masuk'),
-- 	(22,N'Yuniar agung prabowo',N'17:02:10',N'2023-07-21 00:00:00',N'keluar'),
-- 	(23,N'Muhamad ikbal rosadi',N'17:07:19',N'2023-07-21 00:00:00',N'keluar'),
-- 	(23,N'Muhamad ikbal rosadi',N'07:56:53',N'2023-07-21 00:00:00',N'masuk'),
-- 	(24,N'Silvy Natalia',N'07:59:36',N'2023-07-21 00:00:00',N'masuk'),
-- 	(24,N'Silvy Natalia',N'17:04:24',N'2023-07-21 00:00:00',N'keluar'),
-- 	(24,N'Silvy Natalia',N'07:59:40',N'2023-07-21 00:00:00',N'masuk'),
-- 	(24,N'Silvy Natalia',N'17:04:20',N'2023-07-21 00:00:00',N'keluar'),
-- 	(24,N'Silvy Natalia',N'17:09:40',N'2023-07-21 00:00:00',N'keluar'),
-- 	(25,N'Shely',N'07:58:47',N'2023-07-21 00:00:00',N'masuk'),
-- 	(25,N'Shely',N'17:09:35',N'2023-07-21 00:00:00',N'keluar'),
-- 	(26,N'Hery prasetyo',N'07:43:17',N'2023-07-21 00:00:00',N'masuk'),
-- 	(27,N'Monica Mellyanawati',N'17:33:34',N'2023-07-21 00:00:00',N'keluar'),
-- 	(27,N'Monica Mellyanawati',N'07:50:19',N'2023-07-21 00:00:00',N'masuk'),
-- 	(30,N'Wahyu pusporini (arini)',N'07:25:49',N'2023-07-21 00:00:00',N'masuk'),
-- 	(30,N'Wahyu pusporini (arini)',N'17:05:42',N'2023-07-21 00:00:00',N'keluar'),
-- 	(31,N'Rebeca Kristina Lopia Simatupang',N'07:51:08',N'2023-07-21 00:00:00',N'masuk'),
-- 	(31,N'Rebeca Kristina Lopia Simatupang',N'17:11:29',N'2023-07-21 00:00:00',N'keluar'),
-- 	(32,N'Hendrik Pudjo Widodo',N'17:05:37',N'2023-07-21 00:00:00',N'keluar'),
-- 	(32,N'Hendrik Pudjo Widodo',N'07:53:37',N'2023-07-21 00:00:00',N'masuk'),
-- 	(33,N'Melati',N'17:20:52',N'2023-07-21 00:00:00',N'keluar'),
-- 	(33,N'Melati',N'07:21:05',N'2023-07-21 00:00:00',N'masuk'),
-- 	(34,N'Addy putro wahyuono',N'17:35:47',N'2023-07-21 00:00:00',N'keluar'),
-- 	(34,N'Addy putro wahyuono',N'07:29:40',N'2023-07-21 00:00:00',N'masuk'),
-- 	(34,N'Addy putro wahyuono',N'07:29:33',N'2023-07-21 00:00:00',N'masuk'),
-- 	(35,N'Ron reni Mayliana',N'07:55:31',N'2023-07-21 00:00:00',N'masuk'),
-- 	(35,N'Ron reni Mayliana',N'17:06:01',N'2023-07-21 00:00:00',N'keluar'),
-- 	(35,N'Ron reni Mayliana',N'07:45:27',N'2023-07-21 00:00:00',N'masuk'),
-- 	(36,N'Harjanto',N'07:49:26',N'2023-07-21 00:00:00',N'masuk'),
-- 	(36,N'Harjanto',N'17:03:07',N'2023-07-21 00:00:00',N'keluar'),
-- 	(37,N'Ong Lie Djing',N'07:57:15',N'2023-07-21 00:00:00',N'masuk'),
-- 	(37,N'Ong Lie Djing',N'17:14:43',N'2023-07-21 00:00:00',N'keluar'),
-- 	(38,N'Ashley Prawesti Swandini',N'17:09:43',N'2023-07-21 00:00:00',N'keluar'),
-- 	(38,N'Ashley Prawesti Swandini',N'07:47:52',N'2023-07-21 00:00:00',N'masuk'),
-- 	(39,N'Pudji Guntoro',N'07:51:35',N'2023-07-21 00:00:00',N'masuk'),
-- 	(39,N'Pudji Guntoro',N'17:07:45',N'2023-07-21 00:00:00',N'keluar'),
-- 	(41,N'Muchamad Rifai',N'17:08:03',N'2023-07-21 00:00:00',N'keluar'),
-- 	(41,N'Muchamad Rifai',N'07:10:58',N'2023-07-21 00:00:00',N'masuk'),
-- 	(43,N'Mudiono',N'07:29:42',N'2023-07-21 00:00:00',N'masuk'),
-- 	(43,N'Mudiono',N'17:14:00',N'2023-07-21 00:00:00',N'keluar'),
-- 	(44,N'Dwinanto Budi Septyono',N'17:08:07',N'2023-07-21 00:00:00',N'keluar'),
-- 	(44,N'Dwinanto Budi Septyono',N'07:27:51',N'2023-07-21 00:00:00',N'masuk'),
-- 	(45,N'Rony Kristianto Wibowo',N'07:50:48',N'2023-07-21 00:00:00',N'masuk'),
-- 	(46,N'Julius Antonius Juniantoro',N'07:45:33',N'2023-07-21 00:00:00',N'masuk'),
-- 	(47,N'Mulyono',N'17:06:33',N'2023-07-21 00:00:00',N'keluar'),
-- 	(47,N'Mulyono',N'07:46:16',N'2023-07-21 00:00:00',N'masuk'),
-- 	(47,N'Mulyono',N'07:46:21',N'2023-07-21 00:00:00',N'masuk'),
-- 	(48,N'Kusno',N'17:01:25',N'2023-07-21 00:00:00',N'keluar'),
-- 	(48,N'Kusno',N'07:44:40',N'2023-07-21 00:00:00',N'masuk'),
-- 	(49,N'Evita ling',N'17:07:50',N'2023-07-21 00:00:00',N'keluar'),
-- 	(49,N'Evita ling',N'07:37:02',N'2023-07-21 00:00:00',N'masuk');
