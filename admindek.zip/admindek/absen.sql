-- DELETE FROM absen;
-- DELETE FROM olahan;


-- SELECT * from absen
-- order by IDkaryawan,tanggal;
-- SELECT * from olahan;
-- SELECT * from hikvision;
-- ;select * from Members;
-- select top 1000 * from absen order by IDkaryawan,tanggal;
-- ALTER TABLE absen
-- ADD divisi varchar(255),gender varchar(255);
-- SELECT * FROM absen
-- ORDER BY direction DESC;

/* unused query*/
-- UPDATE absen
-- SET direction = case 
-- WHEN jam BETWEEN '05:00:00' and '13:00:59' THEN 'Clock In'
-- WHEN jam BETWEEN '14:01:00' and '19:00:00' THEN 'Clock Out'
-- ELSE 'no data'
-- END;

/*try to use the for select min&max date time value*/
-- WITH tanggal AS (
--   SELECT IDkaryawan, tanggal, direction,
--        CASE WHEN direction = 'Clock In' THEN MIN(jam) ELSE max(jam) END AS selected_jam
--   FROM absen 
--   GROUP BY IDkaryawan, tanggal, direction
-- )
-- DELETE FROM absen
-- WHERE NOT EXISTS 
--       ( SELECT 1 FROM tanggal d
--          WHERE
--             absen.IDkaryawan = d.IDkaryawan AND
--             absen.direction = d.direction AND
--             absen.tanggal = d.tanggal AND
--             absen.jam = d.selected_jam
--       );      

-- SELECT * FROM absen;
-- SELECT * FROM olahan;

/*secfirst query insert where not exist USING MERGE*/
-- merge into 
--     [dbo].[table1] with (holdlock) t  
-- using 
--     (values (1,N'ridho azhar megantara',N'07:44:45',N'2023-07-20',N'masuk')) s([ID_karyawan], [nama_karyawan],[jam],[tanggal],[arah]) 
-- on 
--     t.[ID_karyawan] = s.[ID_karyawan] and t.[nama_karyawan] = s.[nama_karyawan] and t.[jam] = s.[jam] and t.[tanggal] = s.[tanggal] and t.[arah] = s.[arah] 
-- when not matched then 
--     insert values (s.[ID_karyawan], s.[nama_karyawan], s.[jam], s.[tanggal], s.[arah]);

/*insert using merge */
    -- MERGE absen AS Target
    -- USING mekari	AS Source
    -- ON Source.Employee_ID = Target.IDkaryawan
    -- AND Source.Date = Target.tanggal
    
    -- -- For Inserts
    -- WHEN NOT MATCHED BY Target THEN
    --     INSERT (IDkaryawan,tanggal,jam,direction,Location_Setting_Name,Location_GPS_Name,namaKaryawan,divisi,Location_Address,Location_Coordinate,[Description]) 
    --     VALUES (Source.Employee_ID,Source.Date, Source.Check_Time,Source.Type,Source.Location_Setting_Name,Source.Location_GPS_Name,Source.Full_Name,Source.Job_Position,Source.Location_Address,Source.Location_Coordinate,Source.Description)
    
    -- -- For Updates
    -- WHEN MATCHED THEN UPDATE SET
    --     Target.IDkaryawan	                = Source.Employee_ID,
    --     Target.tanggal		                = Source.Date,
    --     Target.jam		                    = Source.Check_Time,
    --     Target.direction		            = Source.Type,
    --     Target.Location_Setting_Name		= Source.Location_Setting_Name,
    --     Target.Location_GPS_Name		    = Source.Location_GPS_Name,
    --     Target.namaKaryawan		            = Source.Full_Name,
    --     Target.divisi		                = Source.Job_Position,
    --     Target.Location_Address		        = Source.Location_Address,
    --     Target.Location_Coordinate		    = Source.Location_Coordinate,
    --     Target.Description		            = Source.Description;

/*second query insert where not exist*/
-- insert into [dbo].[absen] ([IDkaryawan], [tanggal],[jam],[direction],[Location_Setting_Name],[Location_GPS_Name],[namaKaryawan],[divisi],[Location_Address],[Location_Coordinate],[Description]) 
-- select * from ( 
--     values (10, 'tag123') -- sample value 
-- ) as s([post_id], [tag]) 
-- where not exists ( 
--     select * from [dbo].[tags] t with (updlock) 
--     where s.[post_id] = t.[post_id] and s.[tag] = t.[tag] 
-- )

-- /* insert aja*/
-- INSERT INTO absen (IDkaryawan,tanggal,jam,direction,Location_Setting_Name,Location_GPS_Name,namaKaryawan,divisi,Location_Address,Location_Coordinate,[Description])
-- SELECT Employee_ID,[Date],Check_Time,[Type],Location_Setting_Name,Location_GPS_Name,Full_Name,Job_Position,Location_Address,Location_Coordinate,[Description]
-- FROM mekari 
-- WHERE Employee_ID IN (50,46,44,15,47,45,16,26,10,51,17,28,36,23,14,49,23);

/*thirt query insert where not exist*/
--  ;INSERT INTO absen (IDkaryawan,tanggal,jam,direction,Location_Setting_Name,Location_GPS_Name,namaKaryawan,divisi,Location_Address,Location_Coordinate,[Description])
--    SELECT ID_Karyawan,[Date],Check_Time,[Type],Location_Setting_Name,Location_GPS_Name,Full_Name,Job_Position,Location_Address,Location_Coordinate,[Description] 
--    FROM mekariDB
--    WHERE NOT EXISTS (SELECT IDkaryawan,tanggal,jam,direction,Location_Setting_Name,Location_GPS_Name,namaKaryawan,divisi,Location_Address,Location_Coordinate,[Description] FROM  absen  with (updlock)
--    WHERE absen.IDkaryawan = mekariDB.ID_Karyawan 
--    AND absen.tanggal=mekariDB.Date 
--    AND absen.jam=mekariDB.Check_Time 
--    AND absen.direction=mekariDB.Type
--    AND absen.Location_Setting_Name=mekariDB.Location_Setting_Name
--    AND absen.Location_GPS_Name=mekariDB.Location_GPS_Name
--    AND absen.namaKaryawan=mekariDB.Full_Name
--    AND absen.divisi=mekariDB.Job_Position
--    AND absen.Location_Address=mekariDB.Location_Address
--    AND absen.Location_Coordinate=mekariDB.Location_Coordinate
--    AND absen.Description=mekariDB.Description );
/*thirt query insert where not exist from hikvision to absen*/
-- ;INSERT INTO absen (IDkaryawan,namaKaryawan, authDateTime, tanggal,jam,direction)
-- SELECT IDkaryawan, namaKaryawan, authDateTime,tanggal,jam,direction 
-- FROM hikvision 
-- WHERE NOT EXISTS (Select IDkaryawan,namaKaryawan, authDateTime, tanggal,jam,direction From absen with (rowlock,updlock)
-- WHERE absen.IDkaryawan = hikvision.IDkaryawan 
-- AND absen.namaKaryawan=hikvision.namaKaryawan
-- AND absen.authDateTime=hikvision.authDateTime
-- AND absen.tanggal=hikvision.tanggal
-- AND absen.jam=hikvision.jam
-- AND absen.direction=hikvision.direction);
/*fourth query insert where not exist but all*/
-- ;INSERT INTO absen (IDkaryawan,tanggal,jam,direction,Location_Setting_Name,Location_GPS_Name,namaKaryawan,divisi,Location_Address,Location_Coordinate,[Description])
-- SELECT ID_Karyawan,[Date],Check_Time,[Type],Location_Setting_Name,Location_GPS_Name,Full_Name,Job_Position,Location_Address,Location_Coordinate,[Description]
-- FROM mekariDB 
-- WHERE NOT EXISTS (Select 1 From absen  with (updlock)
-- WHERE absen.IDkaryawan=mekariDB.ID_Karyawan and absen.tanggal=mekariDB.Date 
-- and absen.jam=mekariDB.Check_Time and absen.namaKaryawan=mekariDB.Full_Name);

    
/*fiveth query insert just certain ids value*/
-- INSERT INTO absen (IDkaryawan, tanggal, jam, direction, namaKaryawan, divisi)
--     SELECT 
--         Employee_ID, [Date],Check_Time,[Type], 
--         Full_Name, Job_Position 
--     FROM 
--         mekari 
--     WHERE 
--         Employee_ID  IN (50, 46, 44, 15, 47, 45, 16, 26, 10, 51, 17, 28, 36, 23, 14, 49, 23)

/*select olahan last week*/
-- SELECT id FROM tbl
-- WHERE date >= curdate() - INTERVAL DAYOFWEEK(curdate())+6 DAY
-- AND date < curdate() - INTERVAL DAYOFWEEK(curdate())-1 DAY

/*inserting absen table into olahan*/
-- INSERT INTO olahan (ID,Nama, Waktu_masuk, Waktu_pulang,Tanggal,Keterangan1,Keterangan2,uang_makan,uang_makan2)
-- SELECT IDkaryawan
--      , namaKaryawan
--      , MAX(CASE WHEN row_number = 1 THEN jam END) as Waktu_masuk
--      , MIN(CASE WHEN row_number = 2 THEN jam END) as Waktu_pulang
--      , tanggal
--      , MAX(CASE WHEN row_number = 1 THEN Keterangan END) as Keterangan1
--      , MIN(CASE WHEN row_number = 2 THEN Keterangan END) as Keterangan2
--      , MIN(CASE WHEN row_number = 1 THEN uang_makan END) as uang_makan
--      , MIN(CASE WHEN row_number = 2 THEN uang_makan END) as uang_makan2
--   FROM (SELECT IDkaryawan
--              , namaKaryawan
--              , jam
--              , tanggal
--              , Keterangan
--              , ROW_NUMBER() OVER (PARTITION BY IDkaryawan
--                                           , namaKaryawan
--                                           , tanggal
--                                       ORDER BY jam
--                                           ,Keterangan
--                                           ,uang_makan
--                                  ) as row_number
--             ,uang_makan
--           FROM absen 
--        ) AS absen 
-- -- where not exists ( 
-- --     select * from [dbo].[olahan] t with (updlock) 
-- --     where olahan.[ID] = t.[ID] and s.[Nama] = t.[Nama] and s.[Waktu_masuk] = t.[Waktu_masuk] and s.[Keterangan1] = t.[Keterangan1] 
-- --     and s.[Keterangan2] = t.[Keterangan2] and s.[uang_makan] = t.[uang_makan2] 
-- -- )
--  GROUP BY IDkaryawan
--      , namaKaryawan
--      , tanggal
--  order by tanggal
--      , IDkaryawan;


/*selected date from last week*/
-- SELECT tanggal
-- FROM sample2
-- WHERE Created_Date >= DATEADD(day,-11117, GETDATE())


-- SELECT absen.IDkaryawan, absen.namakaryawan, MIN(jam) ,MIN(tanggal),absen.direction
-- FROM absen 
-- GROUP BY IDkaryawan, namakaryawan,jam,tanggal,direction;

-- SELECT * FROM absen ORDER BY IDkaryawan,tanggal

/*try another query for selected time & date*/
-- SELECT IDkaryawan,namaKaryawan,tanggal, 
--     CheckInTime = MIN(CASE WHEN direction='Clock In' THEN jam END),
--     CheckOutTime = MAX(CASE WHEN direction='Clock Out' THEN jam END)
-- FROM absen
-- GROUP BY IDkaryawan,namaKaryawan,tanggal

-- SELECT TOP 5000 * FROM mekari
-- WHERE Employee_ID IN (50,46,44,15,47,45,16,26,10,51,17,28,36,23,14,49,23)
-- ORDER BY Employee_ID DESC;