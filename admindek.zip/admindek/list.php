<html>
<head>
<title>ThaiCreate.Com PHP & SQL Server (sqlsrv)</title>
</head>
<body>
<?php
ini_set('display_errors', 1);
error_reporting(~0);
$serverName = "192.168.0.85";
$userName = "sa";
$userPassword = "manunggal22";
$dbName = "mydatabase";
$connectionInfo = array("Database"=>$dbName, "UID"=>$userName, "PWD"=>$userPassword, "MultipleActiveResultSets"=>true);
$conn = sqlsrv_connect( $serverName, $connectionInfo);
if( $conn === false ) {
die( print_r( sqlsrv_errors(), true));
}
$stmt = "SELECT * FROM customer";
$query = sqlsrv_query($conn, $stmt);
?>
<table width="650" border="1">
<tr>
<th width="91"> <div align="center">CustomerID </div></th>
<th width="98"> <div align="center">Name </div></th>
<th width="198"> <div align="center">Email </div></th>
<th width="97"> <div align="center">CountryCode </div></th>
<th width="59"> <div align="center">Budget </div></th>
<th width="71"> <div align="center">Used </div></th>
<th width="50"> <div align="center">Edit </div></th>
</tr>
<?php
while($result = sqlsrv_fetch_array($query, SQLSRV_FETCH_ASSOC))
{
?>
<tr>
<td><div align="center"><?php echo $result["CustomerID"];?></div></td>
<td><?php echo $result["Name"];?></td>
<td><?php echo $result["Email"];?></td>
<td><div align="center"><?php echo $result["CountryCode"];?></div></td>
<td align="right"><?php echo $result["Budget"];?></td>
<td align="right"><?php echo $result["Used"];?></td>
<td align="center"><a href="edit.php?CustomerID=<?php echo $result["CustomerID"];?>">Edit</a></td>
</tr>
<?php
}
?>
</table>
<?php
sqlsrv_close($conn);
?>
</body>
</html>